package com.file.mapsdemo

import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MainActivity : FragmentActivity(), OnMapReadyCallback, LocationListener {
    var map: GoogleMap? = null
    var locationManage: LocationManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var mapFragment: SupportMapFragment? = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment!!.getMapAsync(this)
        getLocation(this)
    }

    override fun onMapReady(p0: GoogleMap) {
        //p0 = myMap var
        map = p0
        var latLng: LatLng = LatLng(29.498730, -98.536010)
        map!!.addMarker(MarkerOptions().position(latLng))
        map!!.moveCamera(CameraUpdateFactory.newLatLng(latLng))
    }

    fun getLocation(listener: LocationListener){
        locationManage = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if ((ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)){
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
        locationManage!!.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5f, this)
    }

    override fun onLocationChanged(newLoc: Location) {
        var latLng: LatLng = LatLng(newLoc.latitude, newLoc.longitude)
        map!!.addMarker(MarkerOptions().position(latLng))
        map!!.moveCamera(CameraUpdateFactory.newLatLng(latLng))
    }
}